# 美团 JD 对比表

## 全部岗位对比

| 编号 | 岗位名称 | 类别 | 核心工作方向 | 技术栈/框架 | 学历要求 | 经验要求 | 加分项 |
|:---:|:---|:---:|:---|:---|:---:|:---:|:---|
| 【1】【2】 | 大模型算法专家 | 预训练/基座 | 预训练、多模态、scaling law、MoE、reasoning、post-training | PyTorch, Megatron | 不限 | 不限 | 顶会论文、ML竞赛、多模态研究(Gemini/GPT-4o) |
| 【3】 | 多模态大模型算法专家 | 预训练/基座 | 视觉/语音/文本多模态研发、表征学习、跨模态感知/生成 | PyTorch | 不限 | 不限 | NeurIPS/ICML/ICLR/ACL论文、主导多模态项目 |
| 【4】 | 大模型算法专家（Agent方向） | Agent研究 | RL Scaling工具使用、Proactive Agent、长期记忆、多模态/GUI Agent | 不限 | 不限 | **5年+** | 顶会论文、竞赛获奖、主导大影响力项目 |
| 【5】 | 大模型与智能体算法工程师 | Agent落地 | B端业务Agent（商家服务/经营分析）、推理/反思/function call、多智能体 | DeepSeek/Qwen/Llama | 硕士+ | **3年+** | RAG/Function Call/多智能体/RL 任一实践 |
| 【6】 | 大模型算法研究员（RL/Reasoning） | Post-training/RL | General reasoning、test-time scaling、RL scaling（ENV/reward/action）、Agent元能力 | 不限 | 数学/物理/CS | 不限 | 知名大模型团队经验、高影响力论文、AGI信仰 |
| 【7】 | Search Agent大模型算法工程师 | Agent落地 | Search Agent产品（联网搜索/Deep Research）、Mid-Train/RLVR/Agentic RL | PyTorch, TensorFlow | 硕士+ | 不限 | 顶会论文、ACM/Kaggle竞赛 |
| 【8】 | 基座大模型算法研究员（Mid-training） | 预训练/基座 | 万亿级数据处理、合成数据、长上下文、MoE/稀疏注意力、test-time scaling | PyTorch | 不限 | 不限 | Dense/MoE大规模训练经验 |
| 【9】 | 视觉Agent大模型算法专家 | Agent落地 | 视觉Agent全链路（多模态感知/图像生成/跨模态对齐）、多智能体协同 | 主流视觉&多模态LLM | 硕士+ | 不限 | CVPR/ICCV/NeurIPS论文、Agent落地项目 |
| 【10】 | 大模型Agent算法工程师 | Agent研究 | Tool Use、DeepResearch、Agent能力提升（SFT/RL）、规模化落地 | PyTorch, Megatron, DeepSpeed, C++ | 不限 | 不限 | 顶会论文、算法竞赛、开源贡献 |
| 【11】【16】 | Post-training Infra Engineer | Post-training基础设施 | SFT/RL工具链设计开发、训练稳定性/计算效率优化 | Megatron/FSDP, vLLM/SGLang, veRL/openRLHF, CUDA | 不限 | 不限 | 大规模AgenticRL优化经验 |
| 【12】【18】 | 大模型算法工程师/应用算法工程师 | 应用/业务落地 | Post-training、RAG、Graph-RAG、知识图谱融合、AI搜索问答 | PyTorch/TensorFlow, Python/Java | 硕士+ | 不限 | 知识图谱(Neo4j/NebulaGraph)、搜索落地、顶会论文 |
| 【13】 | 大模型应用算法专家（金融） | 应用/金融 | 金融AI电销对话、LLM微调/RLHF/Long context/RAG/Agent | PyTorch/TensorFlow, Python/Java | 本科+ | **4年+** | 生成式模型训练经验、ML赛事获奖 |
| 【14】 | 大模型算法引擎研发工程师 | 应用/MLSys | 架构优化（高效Attention/MoE/量化/剪枝/蒸馏）、训推协同设计 | Megatron, veRL, vLLM, SGLang | 硕博优先 | 不限 | 架构优化顶会论文 |
| 【15】 | 大模型应用研发工程师（金融） | 应用/金融 | 金融AI(催收/电销/IM)全链路工程、RAG工程化、Agent框架、推理优化 | Python/Go/Java, LangChain/LangGraph | 本科+ | **2年+** | LangChain生产落地、语音外呼(ASR/TTS) |
| 【17】 | 基座大模型算法专家 | 预训练/基座 | 基座预训练全链路（数据/训练/对齐）、小型化、高效推理、Scaling Law/MoE | PyTorch | 不限 | 不限 | 顶会论文、权威赛事获奖 |
| 【19】 | 大模型应用算法工程师（点评） | 应用/业务落地 | 智能助理/AI Search/内容生成/人格化机器人、微调/偏好对齐/知识增强 | PyTorch, Python/Java | 硕士+ | **2年+** | 智能助手、生成式搜索项目经验 |

---

## 关键维度横向对比

| 维度 | 岗位 | 备注 |
|:---|:---|:---|
| 经验要求最高 | 【4】Agent研究 | 5年+ |
| 经验要求较高 | 【13】金融应用 | 4年+ |
| 经验要求中等 | 【5】Agent落地、【15】【19】应用落地 | 2~3年+ |
| 经验不限 | 其余所有岗位 | — |
| 学历最低门槛 | 【13】【15】金融方向 | 本科即可 |
| 学历要求最高 | 【14】MLSys | 硕博优先 |
| 偏研究 | 【4】【6】【8】【3】 | 顶会论文权重高 |
| 偏工程落地 | 【5】【7】【10】【11】【15】【16】【19】 | 项目经验权重高 |
