
## 类别分布

| 类别 | 数量 | 岗位编号 |
| :--- | :---: | :--- |
| 预训练/基座模型 | 5 | 【1】【2】【3】【8】【17】 |
| Agent落地 | 3 | 【5】【7】【9】 |
| Agent研究 | 2 | 【4】【10】 |
| Post-training基础设施 | 2 | 【11】【16】 |
| 应用工程/业务落地 | 3 | 【12】【18】【19】 |
| 应用工程/业务落地（金融） | 2 | 【13】【15】 |
| 应用工程/MLSys | 1 | 【14】 |
| Post-training/RL/Reasoning | 1 | 【6】 |
| **合计** | **19** | |

---

【1】：大模型算法专家 - 2026/04/02
https://zhaopin.meituan.com/web/position/detail?jobUnionId=2676335243&highlightType=social
- **类别：** `预训练/基座模型`
- **主要工作：** 聚焦大模型预训练与多模态构建，涵盖 scaling law、MoE 架构、跨模态融合训练等前沿方向。同时负责 reasoning 能力提升和 post-training，最终构建具备通用问题解决能力的 Agent。
- **招聘要求：** 基础要求较低，熟悉主流大模型原理（GPT/BERT/T5）及 PyTorch/Megatron 等训练框架即可。加分项看重顶会论文、ML 竞赛获奖，以及多模态大模型（Gemini、GPT-4o 等）相关研究经验。

【2】：大模型算法专家 - 2026/04/02
https://zhaopin.meituan.com/web/position/detail?jobUnionId=2676335243&highlightType=social
- **类别：** `预训练/基座模型`
- **主要工作：** 聚焦大模型预训练与多模态构建，涵盖 scaling law、MoE 架构、跨模态融合训练等前沿方向。同时负责 reasoning 能力提升和 post-training，最终构建具备通用问题解决能力的 Agent。
- **招聘要求：** 基础要求较低，熟悉主流大模型原理（GPT/BERT/T5）及 PyTorch/Megatron 等训练框架即可。加分项看重顶会论文、ML 竞赛获奖，以及多模态大模型相关研究经验。

【3】：多模态大模型算法专家 - 2025/03/14
https://zhaopin.meituan.com/web/position/detail?jobUnionId=3139280187&highlightType=social
- **类别：** `预训练/基座模型`
- **主要工作：** 参与视觉、语音、文本等多模态大模型研发，探索表征学习和模型架构设计，提升跨模态感知、理解、生成和执行能力。
- **招聘要求：** 熟练掌握 PyTorch 等深度学习框架，熟悉大模型相关算法并有项目实践经验；顶级会议论文（NeurIPS/ICML/ICLR/ACL 等）或曾主导多模态项目者优先。

【4】：大模型算法专家（Agent方向） - 2025/06/23
https://zhaopin.meituan.com/web/position/detail?jobUnionId=3092210943&highlightType=social
- **类别：** `Agent研究`
- **主要工作：** 探索大模型通过 RL Scaling 使用工具解决复杂问题的规划能力，以及 Proactive Agent、长期记忆机制和多模态/GUI Agent 的构建研究。
- **招聘要求：** 需 5 年以上经验，具备强化学习/语言模型等领域深入研究背景；顶会论文、竞赛获奖或主导大影响力项目者优先。

【5】：大模型与智能体算法工程师 - 2025/08/26
https://zhaopin.meituan.com/web/position/detail?jobUnionId=3686817296&highlightType=social
- **类别：** `Agent落地`
- **主要工作：** 负责大模型在 B 端业务场景（商家服务、经营分析）中关键能力（推理、反思、function call）的提升和落地，研发多智能体协调机制。
- **招聘要求：** 硕士及以上，3 年以上相关经验，熟悉主流 LLM（DeepSeek/Qwen/Llama），并在 RAG/Function Call/多智能体/RL 等至少一个方向有实践经验。

【6】：大模型算法研究员-复杂推理/RL方向 - 2025/12/24
https://zhaopin.meituan.com/web/position/detail?jobUnionId=4039654619&highlightType=social
- **类别：** `Post-training/RL/Reasoning`
- **主要工作：** 提升模型 general/frontier reasoning 能力，研究 test-time scaling 和从 ENV/reward/action 三视角的 RL scaling 框架，探索模型作为 Agent 解决数字世界任务的元能力。
- **招聘要求：** 数学/物理/CS 相关专业，具备 post-training 或强化学习经验，有 AGI 信仰；在知名大模型团队有研究经验或发表过高影响力论文者优先。

【7】：Search Agent大模型算法工程师 - 2026/01/05
https://zhaopin.meituan.com/web/position/detail?jobUnionId=3069769778&highlightType=social
- **类别：** `Agent落地`
- **主要工作：** 深度参与大模型 Search Agent 产品研发（联网搜索、边想边搜、Deep Research 等），跟进 Mid-Train/RLVR/Agentic RL 等前沿技术，探索大模型+搜索的新范式。
- **招聘要求：** 硕士及以上，熟悉 PyTorch/TensorFlow 及 LLM 相关算法，有丰富模型训练调优经验；顶会论文或算法竞赛（ACM/Kaggle）获奖者优先。

【8】：基座大模型算法研究员(Mid-training) - 2026/01/08
https://zhaopin.meituan.com/web/position/detail?jobUnionId=3970603311&highlightType=social
- **类别：** `预训练/基座模型`
- **主要工作：** 负责 Trillion 级数据处理体系建设与合成数据策略、长上下文与 MoE/稀疏注意力等高效架构演进，以及 test-time scaling 和模型自进化等下一代训练范式探索。
- **招聘要求：** 熟悉预训练/指令微调/RL 全流程，对 Dense 和 MoE 架构有大规模训练经验，具备扎实算法数学基础及 PyTorch 编程能力。

【9】：视觉Agent大模型算法专家 - 2026/01/12
https://zhaopin.meituan.com/web/position/detail?jobUnionId=3376492114&highlightType=social
- **类别：** `Agent落地`
- **主要工作：** 负责视觉 Agent 系统全链路设计，涵盖多模态感知、图像生成、跨模态对齐（文本-图像-视频），以及多智能体协同任务（工具调用、跨模态推理）的研发与落地。
- **招聘要求：** 计算机/AI/电子工程硕士及以上，熟悉主流视觉及多模态大模型，有任务规划、工具调用等 Agent 框架实际项目经验；顶会论文（CVPR/ICCV/NeurIPS 等）或落地项目优先。

【10】：大模型Agent算法工程师 - 2026/01/16
https://zhaopin.meituan.com/web/position/detail?jobUnionId=3594521007&highlightType=social
- **类别：** `Agent研究`
- **主要工作：** 通过指令微调、强化学习等手段提升大模型的 Tool Use、DeepResearch 等 Agent 能力，参与智能体系统全链路设计并推动 Agent 技术规模化落地。
- **招聘要求：** 熟悉 Agent/LLM/RL/Reasoning Model 等领域，掌握 Python/C++ 等编程语言及 PyTorch/Megatron/DeepSpeed 等框架；顶会论文、算法竞赛获奖或开源贡献者优先。

【11】：Post-training Infrastructure Engineer - 2026/03/25
https://zhaopin.meituan.com/web/position/detail?jobUnionId=4136761943&highlightType=social
- **类别：** `Post-training基础设施`
- **主要工作：** 负责后训练基础设施（SFT、RL 工具链）的设计开发优化，支持 LLM 高效迭代，与算法团队协同解决算法稳定性和计算效率问题。
- **招聘要求：** 熟悉 Megatron/FSDP 等分布式训练框架及 vLLM/SGLang 推理优化，熟悉 veRL/openRLHF 等 RL 框架，具备 Python/C++/CUDA 编程能力；有大规模 AgenticRL 优化经验者优先。

【12】：大模型算法工程师 - 2026/03/05
https://zhaopin.meituan.com/web/position/detail?jobUnionId=4065028909&highlightType=social
- **类别：** `应用工程/业务落地`
- **主要工作：** 探索 Post-training、RAG、知识图谱与大模型深度融合（Graph-RAG）等前沿技术，构建高质量信息处理流水线，增强大模型在 AI 搜索和问答场景的准确性。
- **招聘要求：** 硕士及以上，熟悉 PyTorch/TensorFlow 及 Python/Java，具备良好工程能力；知识图谱（Neo4j/NebulaGraph）构建经验、搜索问答落地经验或顶会论文者优先。

【13】：大模型应用算法专家（金融服务平台） - 2026/03/13
https://zhaopin.meituan.com/web/position/detail?jobUnionId=2783598045&highlightType=social
- **类别：** `应用工程/业务落地（金融）`
- **主要工作：** 负责大模型在金融场景（AI 电销等）的交互式对话应用，探索 LLM 微调、RLHF、Long context、RAG、Agent 等技术，推动业务自动化智能化升级。
- **招聘要求：** 本科及以上，4 年以上经验，熟悉 PyTorch/TensorFlow 及 Python/Java；有生成式模型训练（预训练/微调/RL/Agent）经验或机器学习赛事获奖者优先。

【14】：大模型算法引擎研发工程师 - 2026/03/20
https://zhaopin.meituan.com/web/position/detail?jobUnionId=4254863736&highlightType=social
- **类别：** `应用工程/MLSys`
- **主要工作：** 探索大模型架构优化（高效 Attention、MoE、量化/剪枝/蒸馏），参与美团基座大模型训推算法工程协同设计，并将创新成果落地业务场景。
- **招聘要求：** 硕博优先，熟悉 Megatron/veRL/vLLM/SGLang 等训推框架，具备大模型训练推理算法工程经验；架构优化相关顶会论文者优先。

【15】：大模型应用研发工程师（金融服务平台） - 2026/03/23
https://zhaopin.meituan.com/web/position/detail?jobUnionId=4301017748&highlightType=social
- **类别：** `应用工程/业务落地（金融）`
- **主要工作：** 负责金融领域（AI 催收、AI 电销、AI IM）大模型应用的架构设计和全链路工程落地，覆盖 RAG 工程化、Agent 框架设计、AI 平台能力建设和推理性能优化。
- **招聘要求：** 本科及以上，2 年以上开发经验，熟悉 Python/Go/Java 及 LLM/RAG/Agent 项目经验；LangChain/LangGraph 生产级落地、语音外呼（ASR/TTS）集成等经验者优先。

【16】：Post-training Infrastructure Engineer - 2026/03/25
https://zhaopin.meituan.com/web/position/detail?jobUnionId=4229951483&highlightType=social
- **类别：** `Post-training基础设施`
- **主要工作：** 负责后训练基础设施（SFT、RL 工具链）的设计开发优化，支持 LLM 高效迭代，与算法团队协同解决算法稳定性和计算效率问题。
- **招聘要求：** 熟悉 Megatron/FSDP 等分布式训练框架及 vLLM/SGLang 推理优化，熟悉 veRL/openRLHF 等 RL 框架，具备 Python/C++/CUDA 编程能力；有大规模 AgenticRL 优化经验者优先。

【17】：基座大模型算法专家 - 2026/03/26
https://zhaopin.meituan.com/web/position/detail?jobUnionId=2459467874&highlightType=social
- **类别：** `预训练/基座模型`
- **主要工作：** 负责基座大模型预训练（数据准备、训练加速）、对齐技术（SFT/RLHF）全链路优化，以及模型小型化、高效推理和 Scaling Law/MoE 等前沿技术探索，并对接搜索推荐等业务场景。
- **招聘要求：** 熟悉预训练/指令微调/RLHF 全流程，深入理解 Transformer/GPT/LLaMA/MoE 架构并有大规模训练经验，具备扎实算法数学基础及 PyTorch 编程能力；顶会论文或权威赛事获奖者优先。

【18】：大模型应用算法工程师 - 2026/03/05
https://zhaopin.meituan.com/web/position/detail?jobUnionId=3132074654&highlightType=social
- **类别：** `应用工程/业务落地`
- **主要工作：** 探索 Post-training、RAG、知识图谱与大模型深度融合（Graph-RAG）等前沿技术，构建高质量信息处理流水线，增强大模型在 AI 搜索和问答场景的准确性。
- **招聘要求：** 硕士及以上，熟悉 PyTorch/TensorFlow 及 Python/Java，具备良好工程能力；知识图谱构建经验、搜索问答规模化落地经验或顶会论文者优先。

【19】：大模型应用算法工程师（点评事业部） - 2026/04/01
https://zhaopin.meituan.com/web/position/detail?jobUnionId=4092760861&highlightType=social
- **类别：** `应用工程/业务落地`
- **主要工作：** 负责基于 LLM 的智能交互产品（智能助理、AI Search、内容生成、人格化机器人）在大众点评场景的落地，探索模型微调、偏好对齐、知识增强等技术。
- **招聘要求：** 硕士及以上，2 年以上经验，熟悉 PyTorch 等框架及 Python/Java，需有生成式模型训练和 AI Agent 开发经验；智能助手或生成式搜索项目经验者优先。
