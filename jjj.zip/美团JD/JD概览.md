
【1】：大模型算法专家 - 2026/04/02
https://zhaopin.meituan.com/web/position/detail?jobUnionId=2676335243&highlightType=social

【2】：大模型算法专家 - 2026/04/02
https://zhaopin.meituan.com/web/position/detail?jobUnionId=2676335243&highlightType=social

【3】：多模态大模型算法专家 - 2025/03/14
https://zhaopin.meituan.com/web/position/detail?jobUnionId=3139280187&highlightType=social

【4】：大模型算法专家（Agent方向） - 2025/06/23
https://zhaopin.meituan.com/web/position/detail?jobUnionId=3092210943&highlightType=social

【5】：大模型与智能体算法工程师 - 2025/08/26
https://zhaopin.meituan.com/web/position/detail?jobUnionId=3686817296&highlightType=social

【6】：大模型算法研究员-复杂推理/RL方向 - 2025/12/24
https://zhaopin.meituan.com/web/position/detail?jobUnionId=4039654619&highlightType=social

【7】：Search Agent大模型算法工程师 - 2026/01/05
https://zhaopin.meituan.com/web/position/detail?jobUnionId=3069769778&highlightType=social

【8】：基座大模型算法研究员(Mid-training) - 2026/01/08
https://zhaopin.meituan.com/web/position/detail?jobUnionId=3970603311&highlightType=social

【9】：视觉Agent大模型算法专家 - 2026/01/12
https://zhaopin.meituan.com/web/position/detail?jobUnionId=3376492114&highlightType=social

【10】：大模型Agent算法工程师 - 2026/01/16
https://zhaopin.meituan.com/web/position/detail?jobUnionId=3594521007&highlightType=social

【11】：Post-training Infrastructure Engineer - 2026/03/25
https://zhaopin.meituan.com/web/position/detail?jobUnionId=4136761943&highlightType=social

【12】：大模型算法工程师 - 2026/03/05
https://zhaopin.meituan.com/web/position/detail?jobUnionId=4065028909&highlightType=social

【13】：大模型应用算法专家（金融服务平台） - 2026/03/13
https://zhaopin.meituan.com/web/position/detail?jobUnionId=2783598045&highlightType=social

【14】：大模型算法引擎研发工程师 - 2026/03/20
https://zhaopin.meituan.com/web/position/detail?jobUnionId=4254863736&highlightType=social

【15】：大模型应用研发工程师（金融服务平台） - 2026/03/23
https://zhaopin.meituan.com/web/position/detail?jobUnionId=4301017748&highlightType=social

【16】：Post-training Infrastructure Engineer - 2026/03/25
https://zhaopin.meituan.com/web/position/detail?jobUnionId=4229951483&highlightType=social

【17】：基座大模型算法专家 - 2026/03/26
https://zhaopin.meituan.com/web/position/detail?jobUnionId=2459467874&highlightType=social

【18】：大模型应用算法工程师 - 2026/03/05
https://zhaopin.meituan.com/web/position/detail?jobUnionId=3132074654&highlightType=social

【19】：大模型应用算法工程师（点评事业部） - 2026/04/01
https://zhaopin.meituan.com/web/position/detail?jobUnionId=4092760861&highlightType=social

